

package com.mycompany.chatbot;

/**
 *
 * @author Kiara García
 */
public class Chatbot {

    public static void main(String[] args) {
        Buscar frame= new Buscar();
        frame.setVisible(true);
        frame.setSize(764, 465);
    }
}
